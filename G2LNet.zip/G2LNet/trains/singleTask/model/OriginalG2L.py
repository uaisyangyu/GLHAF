import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.manifold import locally_linear_embedding

from ...subNets.BertTextEncoder import BertTextEncoder
from ...subNets.transformers_encoder.transformer import TransformerEncoder
from ...subNets.OT import LocalOTAlign
from ...subNets.Bottleneck import BottleneckFusion
class G2L(nn.Module):
    def __init__(self, args):
        super(G2L, self).__init__()
        if args.use_bert:
            self.text_model = BertTextEncoder(use_finetune=args.use_finetune, transformers=args.transformers,pretrained=args.pretrained)
        self.use_bert=args.use_bert
        dst_feature_dims, nheads = args.dst_feature_dim_nheads  # [50,10]
        if args.dataset_name == 'mosi':
            if args.need_data_aligned:
                self.len_l, self.len_v, self.len_a = 50, 50, 50
            else:
                self.len_l, self.len_v, self.len_a = 50, 500, 375
        if args.dataset_name == 'mosei':
            if args.need_data_aligned:
                self.len_l, self.len_v, self.len_a = 50, 50, 50
            else:
                self.len_l, self.len_v, self.len_a = 50, 500, 500
        self.orig_d_l, self.orig_d_a, self.orig_d_v = args.feature_dims  # [768, 5, 20]
        self.d_l = self.d_a = self.d_v = dst_feature_dims  # [50]
        self.num_heads = nheads
        self.layers = args.nlevels  # 2
        self.attn_dropout = args.attn_dropout
        self.attn_dropout_a = args.attn_dropout_a
        self.attn_dropout_v = args.attn_dropout_v
        self.relu_dropout = args.relu_dropout
        self.embed_dropout = args.embed_dropout
        self.res_dropout = args.res_dropout
        self.output_dropout = args.output_dropout
        self.text_dropout = args.text_dropout
        self.attn_mask = args.attn_mask
        combined_dim_low = self.d_a
        combined_dim_high = self.d_a
        combined_dim = (self.d_l + self.d_a + self.d_v)
        output_dim = 1
        num_bottleneck=10
        # 1. Temporal convolutional layers for initial feature
        self.proj_l = nn.Conv1d(self.orig_d_l, self.d_l, kernel_size=args.conv1d_kernel_size_l, padding=0, bias=False)  # 卷积核为5
        self.proj_a = nn.Conv1d(self.orig_d_a, self.d_a, kernel_size=args.conv1d_kernel_size_a, padding=0, bias=False)
        self.proj_v = nn.Conv1d(self.orig_d_v, self.d_v, kernel_size=args.conv1d_kernel_size_v, padding=0, bias=False)

        # 2. Global feature encoder
        self.encoder_g = self.get_network(self_type='l', layers = self.layers)

        # 3. Local feature encoder
        self.encoder_s_l = self.get_network(self_type='l', layers=self.layers)
        self.encoder_s_v = self.get_network(self_type='v', layers=self.layers)
        self.encoder_s_a = self.get_network(self_type='a', layers=self.layers)

        # for align g_l, g_v, g_a(对齐全局特征）
        self.align_c_l = nn.Linear(combined_dim_low * (self.len_l - args.conv1d_kernel_size_l + 1), combined_dim_low)#（50×46，50）
        self.align_c_v = nn.Linear(combined_dim_low * (self.len_v - args.conv1d_kernel_size_v + 1), combined_dim_low)
        self.align_c_a = nn.Linear(combined_dim_low * (self.len_a - args.conv1d_kernel_size_a + 1), combined_dim_low)

        self.BFusion = BottleneckFusion(dim=dst_feature_dims,num_bottleneck=20,num_layers=3)
        # for align s_l, s_v, s_a(对齐局部特征）
        self.align_local_tool=LocalOTAlign(eps=0.5,hard=True)
        # 4 Multimodal Crossmodal Attentions
        self.trans_l_with_a = self.get_network(self_type='la', layers=self.layers)
        self.trans_l_with_v = self.get_network(self_type='lv', layers=self.layers)
        self.trans_a_with_l = self.get_network(self_type='al')
        self.trans_a_with_v = self.get_network(self_type='av')
        self.trans_v_with_l = self.get_network(self_type='vl')
        self.trans_v_with_a = self.get_network(self_type='va')
        self.trans_l_mem = self.get_network(self_type='l_mem', layers=self.layers)
        self.trans_a_mem = self.get_network(self_type='a_mem', layers=3)
        self.trans_v_mem = self.get_network(self_type='v_mem', layers=3)
        self.trans_g_with_l = self.get_network(self_type='gl', layers=self.layers)
        self.trans_g_with_v = self.get_network(self_type='gv', layers=self.layers)
        self.trans_g_with_a = self.get_network(self_type='ga', layers=self.layers)

        self.self_attentions_g = self.get_network(self_type='l')



        # 5. fc layers for global features
        self.proj1_l_low = nn.Linear(combined_dim_low * (self.len_l - args.conv1d_kernel_size_l + 1), combined_dim_low)
        self.proj2_l_low = nn.Linear(combined_dim_low, combined_dim_low * (self.len_l - args.conv1d_kernel_size_l + 1))
        self.out_layer_l_low = nn.Linear(combined_dim_low * (self.len_l - args.conv1d_kernel_size_l + 1), output_dim)
        self.proj1_v_low = nn.Linear(combined_dim_low * (self.len_v - args.conv1d_kernel_size_v + 1), combined_dim_low)
        self.proj2_v_low = nn.Linear(combined_dim_low, combined_dim_low * (self.len_v - args.conv1d_kernel_size_v + 1))
        self.out_layer_v_low = nn.Linear(combined_dim_low * (self.len_v - args.conv1d_kernel_size_v + 1), output_dim)
        self.proj1_a_low = nn.Linear(combined_dim_low * (self.len_a - args.conv1d_kernel_size_a + 1), combined_dim_low)
        self.proj2_a_low = nn.Linear(combined_dim_low, combined_dim_low * (self.len_a - args.conv1d_kernel_size_a + 1))
        self.out_layer_a_low = nn.Linear(combined_dim_low * (self.len_a - args.conv1d_kernel_size_a + 1), output_dim)

        # 6. fc layers for local features
        self.proj1_l_high = nn.Linear(combined_dim_high, combined_dim_high)
        self.proj2_l_high = nn.Linear(combined_dim_high, combined_dim_high)
        self.out_layer_l_high = nn.Linear(combined_dim_high, output_dim)
        self.proj1_v_high = nn.Linear(combined_dim_high, combined_dim_high)
        self.proj2_v_high = nn.Linear(combined_dim_high, combined_dim_high)
        self.out_layer_v_high = nn.Linear(combined_dim_high, output_dim)
        self.proj1_a_high = nn.Linear(combined_dim_high, combined_dim_high)
        self.proj2_a_high = nn.Linear(combined_dim_high, combined_dim_high)
        self.out_layer_a_high = nn.Linear(combined_dim_high, output_dim)

        # 7. project for fusion
        self.projector_l = nn.Linear(self.d_l, self.d_l)
        self.projector_v = nn.Linear(self.d_v, self.d_v)
        self.projector_a = nn.Linear(self.d_a, self.d_a)
        self.projector_g = nn.Linear(self.d_l, self.d_l)

        self.proj1_g = nn.Linear(self.d_l, self.d_l )
        self.proj2_g = nn.Linear(self.d_l, self.d_l)
        self.out_layer_g = nn.Linear(self.d_l, output_dim)

        # 8. final project
        self.proj1 = nn.Linear(combined_dim, combined_dim)
        self.proj2 = nn.Linear(combined_dim, combined_dim)
        self.out_layer = nn.Linear(combined_dim, output_dim)


    def get_network(self, self_type='l', layers=-1):
            if self_type in ['l', 'al', 'vl','gl']:
                embed_dim, attn_dropout = self.d_l, self.attn_dropout
            elif self_type in ['a', 'la', 'va','ga']:
                embed_dim, attn_dropout = self.d_a, self.attn_dropout_a
            elif self_type in ['v', 'lv', 'av','gv']:
                embed_dim, attn_dropout = self.d_v, self.attn_dropout_v
            elif self_type == 'l_mem':
                embed_dim, attn_dropout = self.d_l, self.attn_dropout
            elif self_type == 'a_mem':
                embed_dim, attn_dropout = self.d_a, self.attn_dropout
            elif self_type == 'v_mem':
                embed_dim, attn_dropout = self.d_v, self.attn_dropout
            else:
                raise ValueError("Unknown network type")

            return TransformerEncoder(embed_dim=embed_dim,
                                      num_heads=self.num_heads,
                                      layers=max(self.layers, layers),
                                      attn_dropout=attn_dropout,
                                      relu_dropout=self.relu_dropout,
                                      res_dropout=self.res_dropout,
                                      embed_dropout=self.embed_dropout,
                                      attn_mask=self.attn_mask)

    def forward(self, text, audio, video):
            # extraction
            if self.use_bert:
                text = self.text_model(text)
            x_l = F.dropout(text.transpose(1, 2), p=self.text_dropout,
                            training=self.training)  # [batch_size, seq_len, text_dim]->[batch_size, text_dim, seq_len]
            x_a = audio.transpose(1, 2)
            x_v = video.transpose(1, 2)

            proj_x_l = x_l if self.orig_d_l == self.d_l else self.proj_l(
                x_l)  # [768,50,5]     [batch_size, 50, input_len-5+1]
            proj_x_a = x_a if self.orig_d_a == self.d_a else self.proj_a(x_a)  # [5,50,5]
            proj_x_v = x_v if self.orig_d_v == self.d_v else self.proj_v(x_v)  # [20,50,5]
            # 在trasnformer模块需要输入的格式是[lenth,batch_siaze,dim]的形状
            proj_x_l = proj_x_l.permute(2, 0, 1)  # [outlen=length-5+1,batch_size, dim[50]]
            proj_x_v = proj_x_v.permute(2, 0, 1)
            proj_x_a = proj_x_a.permute(2, 0, 1)

            # local feature
            s_l = self.encoder_s_l(proj_x_l)#[lenth,batch_size,dim=50)
            s_v = self.encoder_s_v(proj_x_v)
            s_a = self.encoder_s_a(proj_x_a)

            local_l = s_l.permute(1, 0, 2)  # [batch,length,dim]
            local_v = s_v.permute(1, 0, 2)
            local_a = s_a.permute(1, 0, 2)

            local_align_l = local_l.permute(1, 0, 2)  # [length,batch,dim]
            local_align_v = local_v.permute(1, 0, 2)
            local_align_a = local_a.permute(1, 0, 2)


            # gobal feature
            c_l = self.encoder_g(proj_x_l)#[lenth,batch,dim]
            c_v = self.encoder_g(proj_x_v)
            c_a = self.encoder_g(proj_x_a)

            # s_l = s_l.permute(1, 2, 0)  # [batch,dim,length]
            # s_v = s_v.permute(1, 2, 0)
            # s_a = s_a.permute(1, 2, 0)

            c_l = c_l.permute(1, 2, 0)  # [batch,dim,length]
            c_v = c_v.permute(1, 2, 0)
            c_a = c_a.permute(1, 2, 0)
            c_list = [c_l, c_v, c_a]

            #用于全局模态对齐，CMD损失,展开计算dim*length
            g_align_l=c_l.contiguous().view(x_l.size(0),-1)#[batch_size,dim[50]*length]
            g_align_v=c_v.contiguous().view(x_v.size(0),-1)
            g_align_a=c_a.contiguous().view(x_a.size(0),-1)
            #用于三重损失对齐
            # self.align_c_l = nn.Linear(combined_dim_low * (self.len_l - args.conv1d_kernel_size_l + 1), combined_dim_low) (combined_dim_low[50] * length, combined_dim_low)
            c_l_sim = self.align_c_l(c_l.contiguous().view(x_l.size(0),
                                                           -1))  # [batch_size,dim[50]*length]经过线性变换[batch_size,combined_dim_low[50]]
            c_v_sim = self.align_c_v(c_v.contiguous().view(x_l.size(0), -1))
            c_a_sim = self.align_c_a(c_a.contiguous().view(x_l.size(0), -1))


            c_l = c_l.permute(2, 0, 1)  # [length,batch,dim]
            c_v = c_v.permute(2, 0, 1)
            c_a = c_a.permute(2, 0, 1)


            #信息瓶颈融合
            # g_fusion = self.BFusion(c_l, c_v, c_a)
            g_fusion=torch.cat([c_l, c_v, c_a], dim=0)


            g_att=self.self_attentions_g(g_fusion)
            if type(g_att) == tuple:
                g_att = g_att[0]
            g_att = g_att[-1]  # [batch_size,dim]


            g_proj = self.proj2_g(
                F.dropout(F.relu(self.proj1_g(g_att), inplace=True), p=self.output_dropout,
                          training=self.training))
            g_proj += g_att
            logits_g = self.out_layer_g(g_proj)  # [batch,outdim=1]

            #局部和全局融合
            # g-->l
            h_g=g_fusion


            h_gl=self.trans_g_with_l(h_g,local_align_l,local_align_l)
            h_gl=self.trans_l_mem(h_gl)
            if type(h_gl) == tuple:
                h_gl = h_gl[0]
            last_gl = h_gl[-1]

            h_ga = self.trans_g_with_a(h_g, s_a, s_a)
            h_ga = self.trans_a_mem(h_ga)
            if type(h_ga) == tuple:
                h_ga = h_ga[0]
            last_ga = h_ga[-1]

            h_gv = self.trans_g_with_v(h_g, s_v, s_v)
            h_gv = self.trans_v_mem(h_gv)
            if type(h_gv) == tuple:
                h_gv = h_gv[0]
            last_gv = h_gv[-1]
            #融合后的特征再进行自注意力机制
            hs_proj_l_high = self.proj2_l_high(
                F.dropout(F.relu(self.proj1_l_high(last_gl), inplace=True), p=self.output_dropout,
                          training=self.training))
            hs_proj_l_high += last_gl
            logits_l_high = self.out_layer_l_high(hs_proj_l_high)

            hs_proj_v_high = self.proj2_v_high(
                F.dropout(F.relu(self.proj1_v_high(last_gv), inplace=True), p=self.output_dropout,
                          training=self.training))
            hs_proj_v_high += last_gv
            logits_v_high = self.out_layer_v_high(hs_proj_v_high)

            hs_proj_a_high = self.proj2_a_high(
                F.dropout(F.relu(self.proj1_a_high(last_ga), inplace=True), p=self.output_dropout,
                          training=self.training))
            hs_proj_a_high += last_ga
            logits_a_high = self.out_layer_a_high(hs_proj_a_high)

            # fusion
            last_h_l = torch.sigmoid(self.projector_l(hs_proj_l_high))
            last_h_v = torch.sigmoid(self.projector_v(hs_proj_v_high))
            last_h_a = torch.sigmoid(self.projector_a(hs_proj_a_high))
            c_fusion = torch.sigmoid(self.projector_g(g_proj))

            last_hs = torch.cat([last_h_l, last_h_v, last_h_a], dim=1)

            # prediction
            last_hs_proj = self.proj2(
                F.dropout(F.relu(self.proj1(last_hs), inplace=True), p=self.output_dropout, training=self.training))
            last_hs_proj += last_hs

            output = self.out_layer(last_hs_proj)

            res = {
                'origin_l': proj_x_l,
                'origin_v': proj_x_v,
                'origin_a': proj_x_a,
                'c_l': c_l,
                'c_v': c_v,
                'c_a': c_a,
                's_l': s_l,
                's_v': s_v,
                's_a': s_a,
                'g_align_l': g_align_l,
                'g_align_v': g_align_v,
                'g_align_a': g_align_a,
                'g_fusion': g_fusion,
                'local_l': local_l,
                'local_a': local_a,
                'local_v': local_v,
                'local_align_l': local_align_l,
                'local_align_a':local_align_a,
                'local_align_v':local_align_v,
                'c_l_sim': c_l_sim,
                'c_v_sim': c_v_sim,
                'c_a_sim': c_a_sim,
                'logits_l_hetero': logits_l_high,
                'logits_v_hetero': logits_v_high,
                'logits_a_hetero': logits_a_high,
                'logits_g': logits_g,
                'output_logit': output
            }
            return res