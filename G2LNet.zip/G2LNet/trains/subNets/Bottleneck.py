import torch
from torch import nn



class BottleneckFusion(nn.Module):
    def __init__(self, dim, num_bottleneck, num_layers=3, num_heads=10, dropout=0.1):
        super().__init__()

        def _to_int(x):
            if isinstance(x, torch.Tensor):
                x = x.squeeze()  # 去掉所有 1-D
                if x.numel() != 1:
                    raise ValueError(f"期望单个标量，但得到 shape={x.shape}")
                x = x.item()
            return int(x)

        self.t = _to_int(num_bottleneck)
        self.dim = _to_int(dim)


        # 1. 可学习瓶颈 token  [T, dim]
        self.bottleneck = nn.Parameter(torch.randn(self.t, self.dim))

        # 2. Transformer 编码器（只负责压缩）
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=dim, nhead=num_heads, dropout=dropout, batch_first=False)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        # 3. 可选：下游任务头
        # self.head = nn.Linear(dim, num_classes)

    def forward(self, c_l, c_v, c_a):
        """
        c_l: [L1, B, D]
        c_v: [L2, B, D]
        c_a: [L3, B, D]
        return: [T, B, D]  压缩后的 T 个瓶颈 token
        """
        L1, B, D = c_l.shape
        device = c_l.device

        # 1. 把瓶颈 token 扩到 batch 大小  [T, B, D]
        bottleneck = self.bottleneck.unsqueeze(1).expand(-1, B, -1)

        # 2. 拼接：瓶颈 + 三模态  => [T+L1+L2+L3, B, D]
        src = torch.cat([bottleneck, c_l, c_v, c_a], dim=0)

        # 3. 过 Transformer（无 mask，让瓶颈 token 能 attend 到所有模态）
        out = self.transformer(src)        # 形状不变 [T+L1+L2+L3, B, D]

        # 4. 只取前 T 个瓶颈 token
        bottleneck_out = out[:self.t]      # [T, B, D]

        # 5. 后续可再接均值、Attention 或 Flatten 做任务
        # logits = self.head(bottleneck_out.mean(0))  # 例：均值后分类
        return bottleneck_out              # [T, B, D]
