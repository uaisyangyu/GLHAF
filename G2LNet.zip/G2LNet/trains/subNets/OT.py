# ========== 局部 OT 对齐模块 ==========
import torch
import torch.nn as nn
import torch.nn.functional as F
import ot

class LocalOTAlign(nn.Module):
    """
    输入: Xs ∈ (B, Ts, d)  源模态（如视频帧）
          Xt ∈ (B, Tt, d)  目标模态（如文本token）
    输出: Xs_aligned ∈ (B, Tt, d)  对齐到目标长度
          P       ∈ (B, Ts, Tt)  传输矩阵（可可视化）
    """

    def __init__(self, eps=0.05, hard=True):
        super().__init__()
        self.eps   = eps   # 熵正则系数，hard=True 时无效
        self.hard  = hard  # True->硬分配(论文式5)，False->Sinkhorn软计划

    def forward(self, Xs, Xt):
        B, Ts, d = Xs.shape
        Tt       = Xt.shape[1]

        # 1. 余弦代价矩阵  (B, Ts, Tt)
        Xs_norm = F.normalize(Xs, p=2, dim=-1)   # (B, Ts, d)
        Xt_norm = F.normalize(Xt, p=2, dim=-1)   # (B, Tt, d)
        C = 1 - torch.einsum('bnd,bmd->bnm', Xs_norm, Xt_norm)

        # 2. 逐样本求解 OT 计划
        P_list = []
        for b in range(B):
            cb = C[b]  # (Ts, Tt)
            if self.hard:          # ---- 硬分配（论文式5） ----
                idx  = cb.argmin(dim=1)  # 每行最近邻
                Pbin = torch.zeros_like(cb)
                Pbin[range(Ts), idx] = 1.0 / Ts
            else:                  # ---- 软 Sinkhorn ----
                Pbin = ot.sinkhorn(
                    a=torch.ones(Ts) / Ts,
                    b=torch.ones(Tt) / Tt,
                    M=cb / cb.max(),      # 归一化利于稳定
                    reg=self.eps,
                    numItermax=50)
            P_list.append(Pbin)
        P = torch.stack(P_list, 0)  # (B, Ts, Tt)

        # 3. 用计划把源序列映射到目标长度
        Xs_aligned = torch.bmm(P.transpose(1, 2), Xs)  # (B, Tt, d)
        return Xs_aligned, P

# if __name__ == "__main__":
#         B, Ts, Tt, d = 2, 10, 7, 512
#         vid = torch.randn(B, Ts, d).cuda()
#         txt = torch.randn(B, Tt, d).cuda()
#
#         aligner = LocalOTAlign(hard=True).cuda()
#         vid2txt, plan = aligner(vid, txt)  # vid2txt: (B, Tt, d)
#         print("对齐后形状:", vid2txt.shape)
#         print("传输矩阵可视化（batch-0）:")
#         import matplotlib.pyplot as plt
#         plt.imshow(plan[0].detach().cpu().numpy(), cmap='Blues')
#         plt.xlabel("text token");
#         plt.ylabel("video frame")
#         plt.show()